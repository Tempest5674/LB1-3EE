create definer = root@`%` trigger recepies_BEFORE_INSERT
    before insert
    on recepies
    for each row
BEGIN
	if NEW.runout <=5 OR NEW.runout >=180 then
    signal sqlstate '45000'
    SET MeSSAGE_TEXT = 'Wrong runout (<5 or>180)';
    end if;
END;

