create
    definer = root@`%` procedure addRecepies(IN NEW_IDDoctor int, IN NEW_IDZasobi int, IN NEW_date varchar(50),
                                             IN NEW_runout int, OUT status int)
    IF EXISTS (SELECT * FROM doctor WHERE id = NEW_IDDoctor) 
AND EXISTS (SELECT * FROM zasobi WHERE id = NEW_IDZasobi)
THEN
	INSERT INTO recepies(IDDoctor, IDZasobi, date, runout) 
	VALUES(NEW_IDDoctor,NEW_IDZasobi,NEW_date,NEW_runout);
    SET status = 1;
ELSE
	SET status = 0;
END IF;

