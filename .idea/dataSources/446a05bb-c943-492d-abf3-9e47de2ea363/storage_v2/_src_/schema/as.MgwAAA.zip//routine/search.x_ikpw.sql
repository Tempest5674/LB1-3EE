create
    definer = root@`%` procedure search(IN search_doctor int, OUT result varchar(50))
SELECT name FROM
zasobi INNER JOIN recepies
ON recepies.IDZasobi = zasobi.id
WHERE recepies.IDDoctor = search_doctor INTO result;

