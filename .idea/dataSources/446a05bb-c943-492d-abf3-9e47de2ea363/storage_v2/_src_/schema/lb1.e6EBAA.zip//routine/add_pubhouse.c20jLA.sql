create
    definer = root@`%` procedure add_pubhouse(IN new_NamePubHouse varchar(50), OUT status int)
    IF NOT EXISTS(SELECT * FROM pubhouse
              WHERE NamePubHouse = new_NamePubHouse)
THEN
	INSERT INTO pubhouse(NamePubHouse) VALUES(new_NamePubHouse);
    SET status = 1;
ELSE
	SET status = 0;
END IF;

